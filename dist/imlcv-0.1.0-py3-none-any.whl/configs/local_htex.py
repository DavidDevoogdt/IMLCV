from parsl.config import Config
from parsl.executors import HighThroughputExecutor
from parsl.launchers import SingleNodeLauncher
from parsl.providers import LocalProvider


def get_config(path_internal, py_env):
    provider = LocalProvider(
        min_blocks=1,
        max_blocks=1,
        nodes_per_block=1,
        parallelism=0.5,
        launcher=SingleNodeLauncher(),
    )
    provider_reference = LocalProvider(
        min_blocks=1,
        max_blocks=1,
        nodes_per_block=1,
        parallelism=0.5,
        launcher=SingleNodeLauncher(),
        worker_init=f"export OMP_NUM_THREADS=1;{py_env}",
    )
    executors = [
        HighThroughputExecutor(
            address="localhost",
            label="training",
            working_dir=str(path_internal / "training_executor"),
            provider=provider,
            max_workers=1,
        ),
        HighThroughputExecutor(
            address="localhost",
            label="default",
            working_dir=str(path_internal / "default_executor"),
            provider=provider,
            cores_per_worker=1,
        ),
        HighThroughputExecutor(
            address="localhost",
            label="model",
            working_dir=str(path_internal / "model_executor"),
            provider=provider,
        ),
        HighThroughputExecutor(
            address="localhost",
            label="reference",
            working_dir=str(path_internal / "reference_executor"),
            provider=provider_reference,
            max_workers=1,
            cores_per_worker=4,
            cpu_affinity="block",
        ),
    ]
    return Config(executors, run_dir=str(path_internal), usage_tracking=True)
